// Enhanced Pomodoro Timer with GUI, sound, progress bar, config, and logging

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.sound.sampled.*;

public class PomodoroGUI extends JFrame {
    private static int WORK_DURATION = 25 * 60;
    private static int SHORT_BREAK = 5 * 60;
    private static int LONG_BREAK = 15 * 60;
    private static final int TOTAL_SESSIONS = 4;

    private JLabel label;
    private JButton startButton;
    private Timer timer;
    private int timeLeft;
    private int sessionCount = 0;
    private boolean isWorking = true;
    private JProgressBar progressBar;

    public PomodoroGUI() {
        loadConfig();

        setTitle("Pomodoro Timer");
        setSize(400, 200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        label = new JLabel("Tekan Mulai untuk memulai Pomodoro", SwingConstants.CENTER);
        label.setFont(new Font("SansSerif", Font.BOLD, 16));
        add(label, BorderLayout.NORTH);

        progressBar = new JProgressBar();
        progressBar.setStringPainted(true);
        add(progressBar, BorderLayout.CENTER);

        startButton = new JButton("Mulai Pomodoro");
        add(startButton, BorderLayout.SOUTH);

        startButton.addActionListener(e -> {
            sessionCount = 0;
            mulaiSesiKerja();
        });

        setVisible(true);
    }

    private void mulaiSesiKerja() {
        sessionCount++;
        isWorking = true;
        timeLeft = WORK_DURATION;
        label.setText("Sesi Kerja " + sessionCount + " dimulai");
        notifikasi("Sesi Kerja", "Fokus sekarang!");
        mulaiTimer();
    }

    private void mulaiIstirahat() {
        isWorking = false;
        if (sessionCount == TOTAL_SESSIONS) {
            timeLeft = LONG_BREAK;
            label.setText("Istirahat Panjang dimulai!");
            notifikasi("Istirahat Panjang", "Waktunya istirahat lama!");
        } else {
            timeLeft = SHORT_BREAK;
            label.setText("Istirahat Pendek dimulai");
            notifikasi("Istirahat Pendek", "Ambil nafas dulu");
        }
        mulaiTimer();
    }

    private void mulaiTimer() {
        if (timer != null && timer.isRunning()) timer.stop();
        int totalTime = timeLeft;

        timer = new Timer(1000, new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                int menit = timeLeft / 60;
                int detik = timeLeft % 60;
                label.setText(String.format("%02d:%02d", menit, detik));

                int progress = (int) ((1 - (timeLeft / (double) totalTime)) * 100);
                progressBar.setValue(progress);
                progressBar.setString(progress + "%");

                timeLeft--;
                if (timeLeft < 0) {
                    timer.stop();
                    playSound();

                    if (isWorking) {
                        simpanLog("Sesi Kerja " + sessionCount + " selesai.");
                        mulaiIstirahat();
                    } else {
                        if (sessionCount < TOTAL_SESSIONS) {
                            mulaiSesiKerja();
                        } else {
                            label.setText("Selesai! Kamu hebat!");
                            simpanLog("Selesai 4 sesi Pomodoro.");
                            notifikasi("Selesai", "Semua sesi selesai! Istirahat total!");
                            startButton.setEnabled(true);
                        }
                    }
                }
            }
        });

        startButton.setEnabled(false);
        timer.start();
    }

    private void notifikasi(String title, String message) {
        Toolkit.getDefaultToolkit().beep();
        JOptionPane.showMessageDialog(this, message, title, JOptionPane.INFORMATION_MESSAGE);
    }

    private void simpanLog(String pesan) {
        try (FileWriter fw = new FileWriter("pomodoro_log.txt", true)) {
            String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
            fw.write(timestamp + " - " + pesan + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void playSound() {
        try {
            AudioInputStream audio = AudioSystem.getAudioInputStream(new File("beep.wav"));
            Clip clip = AudioSystem.getClip();
            clip.open(audio);
            clip.start();
        } catch (Exception e) {
            Toolkit.getDefaultToolkit().beep();
        }
    }

    private void loadConfig() {
        File cfg = new File("pomodoro.cfg");
        if (!cfg.exists()) return;
        try (BufferedReader br = new BufferedReader(new FileReader(cfg))) {
            WORK_DURATION = Integer.parseInt(br.readLine()) * 60;
            SHORT_BREAK = Integer.parseInt(br.readLine()) * 60;
            LONG_BREAK = Integer.parseInt(br.readLine()) * 60;
        } catch (Exception e) {
            System.out.println("Gagal baca config, pakai default.");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new PomodoroGUI());
    }
}
